const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000; 

// --- Middlewares ---
app.use(cors()); 
app.use(express.json()); 

// --- Rotas ---
const foodRoutes = require('./routes/foods');
const userRoutes = require('./routes/users');
const cartRoutes = require('./routes/cart');

// ============ CORREÇÃO DA ORDEM ============
// As rotas mais específicas ( /foods, /cart ) devem vir PRIMEIRO.
app.use('/foods', foodRoutes);
app.use('/cart', cartRoutes);
app.use('/assets', express.static(path.join(__dirname, 'assets')));

// A rota mais geral ( / ) deve vir por ÚLTIMO.
app.use('/', userRoutes);      
// ===========================================

// --- Inicialização do Servidor ---
app.listen(PORT, () => {
    console.log(`Servidor MenuExpress rodando na porta ${PORT}`);
    console.log('Endpoints disponíveis:');
    console.log('  POST /login');
    console.log('  POST /register');
    console.log('  GET /foods');
    console.log('  POST /cart/add');
    console.log('  GET /cart/:userEmail');
    console.log('  POST /cart/remove'); 
    console.log('  POST /cart/clear');
});
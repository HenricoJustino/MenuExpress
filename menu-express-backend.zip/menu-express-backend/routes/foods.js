const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

const foodsPath = path.join(__dirname, '../data/foods.json');

// Rota GET /foods [cite: 96]
// Retorna a lista de pratos do cardápio
router.get('/', (req, res) => {
    fs.readFile(foodsPath, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).json({ message: "Erro ao ler o cardápio." });
        }
        res.json(JSON.parse(data));
    });
});

module.exports = router;
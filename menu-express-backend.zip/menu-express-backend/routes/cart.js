const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

const cartPath = path.join(__dirname, '../data/cart.json');

// --- Nova Função Síncrona ---
function getCartSync() {
    try {
        const data = fs.readFileSync(cartPath, 'utf8');
        // Se o arquivo estiver vazio, retorne {}
        if (data.trim() === "") {
            return {};
        }
        return JSON.parse(data);
    } catch (err) {
        // Se o arquivo não existir ou o JSON estiver quebrado, retorne {}
        return {};
    }
}

// --- Nova Função Síncrona ---
function saveCartSync(cartData) {
    try {
        fs.writeFileSync(cartPath, JSON.stringify(cartData, null, 2), 'utf8');
        return true; // Sucesso
    } catch (err) {
        console.error("ERRO AO SALVAR O CARRINHO:", err);
        return false; // Falha
    }
}

// Rota GET /cart/:userEmail
router.get('/:userEmail', (req, res) => {
    const { userEmail } = req.params;
    const cart = getCartSync(); // Leitura Síncrona
    
    const userCart = cart[userEmail] || [];
    res.status(200).json(userCart);
});

// Rota POST /cart/add
router.post('/add', (req, res) => {
    try {
        const { userEmail, foodItem } = req.body;
        if (!userEmail || !foodItem) {
            return res.status(400).json({ message: "Usuário e item são obrigatórios." });
        }

        const cart = getCartSync(); // Leitura Síncrona

        const userCart = cart[userEmail] || [];
        userCart.push(foodItem);
        cart[userEmail] = userCart;

        const success = saveCartSync(cart); // Escrita Síncrona

        if (success) {
            res.status(200).json({ message: "Item adicionado ao carrinho!" });
        } else {
            res.status(500).json({ message: "Erro ao salvar o carrinho no servidor." });
        }

    } catch (error) {
        console.error("ERRO NA ROTA /cart/add:", error);
        res.status(500).json({ message: "Erro interno do servidor." });
    }
});

// Rota POST /cart/remove
router.post('/remove', (req, res) => {
    try {
        const { userEmail, foodId } = req.body;
        if (!userEmail || !foodId) {
            return res.status(400).json({ message: "Usuário e ID do item são obrigatórios." });
        }

        const cart = getCartSync(); // Leitura Síncrona
        const userCart = cart[userEmail];

        if (!userCart) {
            return res.status(404).json({ message: "Carrinho não encontrado." });
        }

        const itemIndex = userCart.findIndex(item => item.id === foodId);
        if (itemIndex > -1) {
            userCart.splice(itemIndex, 1);
            cart[userEmail] = userCart;
        } else {
            return res.status(404).json({ message: "Item não encontrado." });
        }

        const success = saveCartSync(cart); // Escrita Síncrona

        if (success) {
            res.status(200).json({ message: "Item removido!" });
        } else {
            res.status(500).json({ message: "Erro ao salvar o carrinho no servidor." });
        }

    } catch (error) {
        console.error("ERRO NA ROTA /cart/remove:", error);
        res.status(500).json({ message: "Erro interno do servidor." });
    }
});

// ========= NOVA ROTA PARA LIMPAR O CARRINHO =========
router.post('/clear', (req, res) => {
    try {
        const { userEmail } = req.body;
        if (!userEmail) {
            return res.status(400).json({ message: "Usuário é obrigatório." });
        }

        const cart = getCartSync(); // Leitura Síncrona

        // Verifica se o usuário tem um carrinho
        if (cart[userEmail]) {
            // Limpa o carrinho do usuário
            cart[userEmail] = []; 
            
            const success = saveCartSync(cart); // Salva o objeto de carrinhos atualizado

            if (success) {
                res.status(200).json({ message: "Carrinho limpo com sucesso!" });
            } else {
                res.status(500).json({ message: "Erro ao salvar o carrinho no servidor." });
            }
        } else {
            // Se o usuário não tiver um carrinho, já está limpo
            res.status(200).json({ message: "Carrinho já estava limpo." });
        }

    } catch (error) {
        console.error("ERRO NA ROTA /cart/clear:", error);
        res.status(500).json({ message: "Erro interno do servidor." });
    }
});

module.exports = router;
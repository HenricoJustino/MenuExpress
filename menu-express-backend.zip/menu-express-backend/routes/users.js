const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

const usersPath = path.join(__dirname, '../data/users.json');

// Função auxiliar para ler usuários
function getUsers(callback) {
    fs.readFile(usersPath, 'utf8', (err, data) => {
        if (err) {
            return callback(err, null);
        }
        try {
            const users = JSON.parse(data);
            callback(null, users);
        } catch (parseErr) {
            callback(parseErr, null);
        }
    });
}

// Função auxiliar para salvar usuários
function saveUsers(users, callback) {
    fs.writeFile(usersPath, JSON.stringify(users, null, 2), 'utf8', (err) => {
        callback(err);
    });
}

// Rota POST /register [cite: 92]
router.post('/register', (req, res) => {
    const { nome, email, pass } = req.body; // Vem do app Android

    if (!email || !pass || !nome) {
        return res.status(400).json({ message: "Nome, e-mail e senha são obrigatórios." });
    }

    getUsers((err, users) => {
        if (err) {
            return res.status(500).json({ message: "Erro interno ao ler usuários." });
        }

        // Verifica se o usuário já existe
        const userExists = users.find(u => u.email === email);
        if (userExists) {
            return res.status(400).json({ message: "E-mail já cadastrado." });
        }

        // Adiciona novo usuário
        const newUser = { id: Date.now().toString(), nome, email, pass }; // pass (senha)
        users.push(newUser);

        // Salva a lista atualizada
        saveUsers(users, (err) => {
            if (err) {
                return res.status(500).json({ message: "Erro ao salvar novo usuário." });
            }
            // Retorna o novo usuário (sem a senha)
            res.status(201).json({ id: newUser.id, nome: newUser.nome, email: newUser.email });
        });
    });
});

// Rota POST /login [cite: 94]
router.post('/login', (req, res) => {
    const { email, pass } = req.body;

    if (!email || !pass) {
        return res.status(400).json({ message: "E-mail e senha são obrigatórios." });
    }

    getUsers((err, users) => {
        if (err) {
            return res.status(500).json({ message: "Erro interno ao ler usuários." });
        }

        // Procura pelo usuário
        const user = users.find(u => u.email === email);

        // Verifica o usuário e a senha
        if (!user || user.pass !== pass) {
            return res.status(401).json({ message: "E-mail ou senha inválidos." });
        }

        // Login bem-sucedido
        // (Em um app real, aqui você geraria um Token JWT)
        res.status(200).json({ 
            message: "Login bem-sucedido!",
            user: { id: user.id, nome: user.nome, email: user.email } 
        });
    });
});

module.exports = router;